package tests;

import com.codename1.testing.AbstractTest;

import com.codename1.ui.Display;

public class Integrationstest extends AbstractTest {
    public boolean runTest() throws Exception {
        assertTitle("TicTacToe");
        assertTitle("TicTacToe");
        waitForFormName("TicTacToeOffline");
        clickButtonByName("btn_1");
        clickButtonByName("btn_2");
        clickButtonByName("btn_3");
        waitForFormTitle("You won");
        Display.getInstance().getCurrent().setName("Form_1");
        goBack();
        waitForFormName("TicTacToeOffline");
        waitForFormTitle("You won");
        Display.getInstance().getCurrent().setName("Form_2");
        goBack();
        waitForFormName("TicTacToeOffline");
        waitForFormTitle("You won");
        Display.getInstance().getCurrent().setName("Form_3");
        goBack();
        waitForFormName("TicTacToeOffline");
        return true;
    }
}
