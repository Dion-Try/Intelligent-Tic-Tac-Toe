/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import TicTacToe.Computer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Harish
 */
public class UnitTestComputer {
    
    public UnitTestComputer() {
    }
    private static Computer Computerai;
    
    @BeforeAll
    public static void setUpClass() {
      Computerai = new Computer();
      System.out.println("Start!");  
    }
    
    @AfterAll
    public static void tearDownClass() {
        System.out.println("nach Test");
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     public void derTest1() {
      // Testfall 1: Prüfung ob Umfangsberechnung stimmt
      System.out.println("Test1");
     
   }
    
   @Test
   public void derTest2() {
      // Testfall 2: Prüfung ob Flächeninhaltsberechnung stimmt
      System.out.println("Test2");
     
   }
    
}
